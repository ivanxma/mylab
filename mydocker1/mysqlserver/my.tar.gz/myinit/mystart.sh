#! /bin/bash
echo "running mysqlsh"

/usr/local/shell/bin/mysqlsh --version

/usr/bin/ls -l /
/usr/bin/ls -l /usr/*

