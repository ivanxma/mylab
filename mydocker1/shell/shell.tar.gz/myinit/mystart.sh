#! /bin/bash
echo "running mysqlsh"

/usr/local/shell/bin/mysqlsh -f /myinit/my.js
echo ""
echo "exit mysqlsh"

