print("this is JS")
