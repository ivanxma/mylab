export PATH=/usr/local/mysql/bin:/usr/local/shell/bin:$PATH
